package model.charactersModel.enemies;

public class TriangleModel {
}
