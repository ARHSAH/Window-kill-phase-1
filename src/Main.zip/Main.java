import controller.Update;
import model.charactersModel.enemies.SquareModel;
import view.panelsView.MainView;

public class Main {
    public static void main(String[] args) {
        //new SquareModel();
        new MainView();

    }
}