import controller.Update;
import view.panelsView.MainView;

public class Main {
    public static void main(String[] args) {
        new MainView();

    }
}